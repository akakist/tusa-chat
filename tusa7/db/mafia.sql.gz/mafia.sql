-- MySQL dump 10.11
--
-- Host: localhost    Database: mafia
-- ------------------------------------------------------
-- Server version	5.0.67

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `score`
--

DROP TABLE IF EXISTS `score`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `score` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `login` char(18) NOT NULL default '',
  `win` int(11) NOT NULL default '0',
  `loose` int(11) NOT NULL default '0',
  `score` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `_login` (`login`),
  KEY `_win` (`win`),
  KEY `_loose` (`loose`),
  KEY `_score` (`score`)
) ENGINE=MyISAM AUTO_INCREMENT=2558 DEFAULT CHARSET=cp1251 PACK_KEYS=1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `score`
--

LOCK TABLES `score` WRITE;
/*!40000 ALTER TABLE `score` DISABLE KEYS */;
INSERT INTO `score` VALUES (2446,'hitmans',28,29,2825),(2447,'Lena',5,2,376),(2448,'blah',17,14,2088),(2449,'Temsky',1,1,67),(2450,'Dabizas',2,5,43),(2451,'Horsefair',40,32,3392),(2452,'Dinka007',3,8,208),(2453,'ip',2,0,281),(2454,'El*',6,11,680),(2455,'Em1243mm',10,7,902),(2456,'V0LK',8,14,751),(2457,'elenalg',16,16,1594),(2458,'0102Angel',4,15,555),(2459,'Natashka2003',10,11,815),(2460,'oloy',2,0,253),(2461,'der_Genosse',9,15,706),(2462,'4r5t6y',7,6,304),(2463,'hl0456',0,2,0),(2464,'Posya',2,0,21),(2465,'Laman',3,3,262),(2466,'Patience',1,1,120),(2467,'resk',5,6,744),(2468,'Maslinka',6,11,395),(2469,'Rulez',6,4,517),(2470,'degrott',2,1,50),(2471,'21BAM',2,3,369),(2472,'DagmaraM',2,1,110),(2473,'*Lessa*',1,0,35),(2474,'freenat2d',1,1,35),(2475,'Ahdrey',2,2,72),(2476,'buca',14,11,1314),(2477,'dadflamex',76,85,8132),(2478,'cifra1',48,33,5810),(2479,'friendlygirl',21,14,2063),(2480,'levab',4,7,65),(2481,'reg23',2,3,132),(2482,'GURD',2,1,83),(2483,'misterg',2,1,220),(2484,'Rogachev2',2,1,-50),(2485,'daughter',1,2,82),(2486,'alex64',23,25,2476),(2487,'Legend',3,12,576),(2488,'ferdinand',10,9,1166),(2489,'sova4ka',2,0,202),(2490,'koly86',1,2,72),(2491,'kostilkevich',6,13,1139),(2492,'haljwin6',3,1,321),(2493,'Baleriy',3,1,150),(2494,'REW',0,1,0),(2495,'Alex_o',1,0,50),(2496,'kissme5times',0,1,0),(2497,'seldom733',12,19,1961),(2498,'edge1',2,2,247),(2499,'Serg_port',1,1,50),(2500,'stanR',8,3,708),(2501,'ded334',3,9,514),(2502,'vbvb',14,11,1209),(2503,'isokol',3,5,336),(2504,'8304',16,14,1678),(2505,'brat3',1,1,140),(2506,'Butovo',1,1,119),(2507,'cjhjrbyf',13,12,1125),(2508,'krisko',10,12,937),(2509,'SADE',4,4,227),(2510,'alkaloid',8,14,1255),(2511,'tblast',3,7,198),(2512,'rada87',1,0,216),(2513,'331a',2,5,279),(2514,'Bruynet_Visokiy',4,6,386),(2515,'poiuyt',1,4,126),(2516,'kanareika2004',19,19,2112),(2517,'11nik',1,5,126),(2518,'VVVVV',4,1,405),(2519,'fifann',9,14,950),(2520,'kozubm',1,7,272),(2521,'Zellua',1,3,-95),(2522,'tanchonok',1,0,-50),(2523,'Chebura6ka',45,49,3714),(2524,'pupsik-dyavol007',7,9,452),(2525,'OLIAS',13,16,1570),(2526,'soloveyka',5,7,650),(2527,'rkim',6,6,519),(2528,'fanveld',10,12,963),(2529,'Ninkale2000',4,3,202),(2530,'vitarapka',0,2,10),(2531,'konami',13,19,1525),(2532,'Masxadov',1,1,-50),(2533,'MILKY',0,2,61),(2534,'zolotoww',3,3,64),(2535,'karleona',3,3,98),(2536,'gsm01',1,0,118),(2537,'slava31419',0,1,0),(2538,'koreetsss',1,0,50),(2539,'Stanislav14',1,3,211),(2540,'6241',6,7,493),(2541,'Mamzel',5,9,270),(2542,'hgfdsa',5,2,549),(2543,'gertsog',6,10,714),(2544,'irada74',8,3,678),(2545,'blablabla-bla',2,1,307),(2546,'seller777',2,0,97),(2547,'damka200',0,1,0),(2548,'greeneyezzz',1,0,50),(2549,'studentin',6,5,550),(2550,'zlataaa',0,1,0),(2551,'ZMAN',3,7,331),(2552,'*VIK*',0,1,-50),(2553,'mileishaya',2,1,56),(2554,'Lu777',1,2,0),(2555,'Bibob3d',1,0,110),(2556,'AlbertEinstein',1,0,-16),(2557,'ZERG_P',1,2,49);
/*!40000 ALTER TABLE `score` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-04-08 18:15:11
