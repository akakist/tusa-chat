-- MySQL dump 10.11
--
-- Host: localhost    Database: chat
-- ------------------------------------------------------
-- Server version	5.0.67

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anekdots`
--

DROP TABLE IF EXISTS `anekdots`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `anekdots` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `txt` text,
  `rating` int(11) NOT NULL default '0',
  `add_date` datetime default NULL,
  `add_by` text,
  `chk` int(1) NOT NULL default '0',
  `ip` text,
  PRIMARY KEY  (`ID`),
  KEY `chk_k` (`chk`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `anekdots`
--

LOCK TABLES `anekdots` WRITE;
/*!40000 ALTER TABLE `anekdots` DISABLE KEYS */;
/*!40000 ALTER TABLE `anekdots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_ip`
--

DROP TABLE IF EXISTS `banned_ip`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `banned_ip` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `ip` text,
  `proxy` text,
  `time_ban` datetime default NULL,
  `time_free` datetime default NULL,
  `time_cnt` text,
  `uid` int(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `uidk` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=7222 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `banned_ip`
--

LOCK TABLES `banned_ip` WRITE;
/*!40000 ALTER TABLE `banned_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_login`
--

DROP TABLE IF EXISTS `banned_login`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `banned_login` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `login` text,
  `time_ban` datetime default NULL,
  `time_free` datetime default NULL,
  `time_cnt` text,
  `uid` int(20) unsigned NOT NULL default '0',
  `descr` text NOT NULL,
  `buid` int(11) NOT NULL default '0',
  `adm_uid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `uidk` (`uid`),
  KEY `adm_uid` (`adm_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `banned_login`
--

LOCK TABLES `banned_login` WRITE;
/*!40000 ALTER TABLE `banned_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner_declines`
--

DROP TABLE IF EXISTS `banner_declines`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `banner_declines` (
  `banner` int(20) unsigned NOT NULL default '0',
  `reason` text,
  KEY `_banner` (`banner`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `banner_declines`
--

LOCK TABLES `banner_declines` WRITE;
/*!40000 ALTER TABLE `banner_declines` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner_declines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `banners` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `owner` int(20) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `url` text,
  `alt` text,
  `descr` text,
  `orig_filename` text,
  `path` text,
  `r1` char(1) NOT NULL default '0',
  `r2` char(1) NOT NULL default '0',
  `width` int(5) unsigned NOT NULL default '0',
  `height` int(5) unsigned NOT NULL default '0',
  `enabled` char(1) NOT NULL default '0',
  `checked` char(1) NOT NULL default '0',
  `creation_time` datetime default NULL,
  `modification_time` datetime default NULL,
  `deleted` char(1) NOT NULL default '0',
  `total_shown_N` int(10) unsigned NOT NULL default '0',
  `total_shown_cost` double(16,4) NOT NULL default '0.0000',
  `decline_reason` text,
  `total_click_N` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `_owner` (`owner`),
  KEY `_name` (`name`),
  KEY `_width` (`width`),
  KEY `_height` (`height`),
  KEY `_enabled` (`enabled`),
  KEY `_checked` (`checked`),
  KEY `_deleted` (`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_advertizers`
--

DROP TABLE IF EXISTS `bx_advertizers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_advertizers` (
  `refid` int(20) unsigned NOT NULL default '0',
  `remained_sum` double(16,4) NOT NULL default '0.0000',
  `shown_total_sum` double(16,4) NOT NULL default '0.0000',
  `credit_limit_sum` double(16,4) NOT NULL default '0.0000',
  `payed_sum` double(16,4) NOT NULL default '0.0000',
  `auto_allow` char(1) NOT NULL default '0',
  `min_price` double NOT NULL default '1',
  KEY `_refid` (`refid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_advertizers`
--

LOCK TABLES `bx_advertizers` WRITE;
/*!40000 ALTER TABLE `bx_advertizers` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_advertizers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_click_log`
--

DROP TABLE IF EXISTS `bx_click_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_click_log` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `banner` int(20) unsigned NOT NULL default '0',
  `user` int(20) unsigned NOT NULL default '0',
  `gender` char(1) NOT NULL default '0',
  `click_time` datetime default NULL,
  `url` blob,
  `ip` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `_banner` (`banner`),
  KEY `_gender` (`gender`),
  KEY `_click_time` (`click_time`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_click_log`
--

LOCK TABLES `bx_click_log` WRITE;
/*!40000 ALTER TABLE `bx_click_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_click_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_groups`
--

DROP TABLE IF EXISTS `bx_groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_groups` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `name` text,
  `descr` text,
  `deleted` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_groups`
--

LOCK TABLES `bx_groups` WRITE;
/*!40000 ALTER TABLE `bx_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_money_transactions`
--

DROP TABLE IF EXISTS `bx_money_transactions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_money_transactions` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `summa` double(16,4) NOT NULL default '0.0000',
  `from_user` int(20) unsigned NOT NULL default '0',
  `to_user` int(20) unsigned NOT NULL default '0',
  `committed` char(1) NOT NULL default '0',
  `create_time` datetime default NULL,
  `commit_time` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `_fu` (`from_user`),
  KEY `_tu` (`to_user`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_money_transactions`
--

LOCK TABLES `bx_money_transactions` WRITE;
/*!40000 ALTER TABLE `bx_money_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_money_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_orders`
--

DROP TABLE IF EXISTS `bx_orders`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_orders` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `owner` int(20) unsigned NOT NULL default '0',
  `banner` int(20) unsigned NOT NULL default '0',
  `name` text,
  `descr` text,
  `cost1000` double(4,2) NOT NULL default '0.00',
  `date_targeting` text,
  `week_targeting` text,
  `day_targeting` text,
  `host_targeting` text,
  `gender_targeting` char(1) NOT NULL default '0',
  `user_packet_size` int(8) unsigned NOT NULL default '0',
  `user_packet_interval` int(8) unsigned NOT NULL default '0',
  `user_packet_exterval` int(8) unsigned NOT NULL default '0',
  `max_shows_total` int(8) unsigned NOT NULL default '0',
  `deleted` char(1) NOT NULL default '0',
  `creation_time` datetime default NULL,
  `modification_time` datetime default NULL,
  `total_shown_N` int(10) unsigned NOT NULL default '0',
  `total_shown_cost` double(16,4) NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  KEY `_banner` (`banner`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_orders`
--

LOCK TABLES `bx_orders` WRITE;
/*!40000 ALTER TABLE `bx_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_place`
--

DROP TABLE IF EXISTS `bx_place`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_place` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `system` int(20) unsigned NOT NULL default '0',
  `site` int(20) unsigned NOT NULL default '0',
  `name` text,
  `descr` text,
  `page_url` text,
  `cost1000` double default NULL,
  `deleted` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_place`
--

LOCK TABLES `bx_place` WRITE;
/*!40000 ALTER TABLE `bx_place` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_show_log`
--

DROP TABLE IF EXISTS `bx_show_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_show_log` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `banner` int(20) unsigned NOT NULL default '0',
  `ordr` int(20) unsigned NOT NULL default '0',
  `user` int(20) unsigned NOT NULL default '0',
  `cost` double(16,4) NOT NULL default '0.0000',
  `gender` char(1) NOT NULL default '0',
  `show_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ip` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `_banner` (`banner`),
  KEY `_order` (`ordr`),
  KEY `_gender` (`gender`),
  KEY `_show_time` (`show_time`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_show_log`
--

LOCK TABLES `bx_show_log` WRITE;
/*!40000 ALTER TABLE `bx_show_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_show_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_sites`
--

DROP TABLE IF EXISTS `bx_sites`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_sites` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `owner` int(20) unsigned NOT NULL default '0',
  `name` text,
  `descr` text,
  `hostname` text,
  `deleted` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_sites`
--

LOCK TABLES `bx_sites` WRITE;
/*!40000 ALTER TABLE `bx_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_systems`
--

DROP TABLE IF EXISTS `bx_systems`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_systems` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `width` int(20) unsigned NOT NULL default '0',
  `height` int(20) unsigned NOT NULL default '0',
  `name` text,
  `descr` text,
  `deleted` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_systems`
--

LOCK TABLES `bx_systems` WRITE;
/*!40000 ALTER TABLE `bx_systems` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_systems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bx_viewers`
--

DROP TABLE IF EXISTS `bx_viewers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bx_viewers` (
  `refid` int(20) unsigned NOT NULL default '0',
  `modification_time` datetime default NULL,
  `container` blob,
  KEY `_refid` (`refid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bx_viewers`
--

LOCK TABLES `bx_viewers` WRITE;
/*!40000 ALTER TABLE `bx_viewers` DISABLE KEYS */;
/*!40000 ALTER TABLE `bx_viewers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `channels` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `censored` int(2) default '1',
  `save` char(1) default '1',
  `move_to_channel` int(10) default '0',
  `move` char(1) default '0',
  `no_stat` char(1) NOT NULL default '0',
  `ext` char(1) NOT NULL default '0',
  `read_level` int(4) NOT NULL default '0',
  `write_level` int(4) NOT NULL default '0',
  `irc_name` text,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels_names`
--

DROP TABLE IF EXISTS `channels_names`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `channels_names` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `cid` int(20) unsigned NOT NULL default '0',
  `lang` char(3) default '',
  `name` text,
  PRIMARY KEY  (`ID`),
  KEY `cid_key` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `channels_names`
--

LOCK TABLES `channels_names` WRITE;
/*!40000 ALTER TABLE `channels_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `channels_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `contact` (
  `uid` int(11) NOT NULL default '0',
  `cuid` int(11) NOT NULL default '0',
  `flags` int(11) NOT NULL default '0',
  KEY `uid` (`uid`),
  KEY `cuid` (`cuid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_bank`
--

DROP TABLE IF EXISTS `credit_bank`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `credit_bank` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `code` varchar(10) NOT NULL default '',
  `summa` double NOT NULL default '0',
  `touid` int(10) unsigned NOT NULL default '0',
  `comment` text,
  `dt` datetime NOT NULL default '2006-01-01 00:00:00',
  PRIMARY KEY  (`ID`),
  KEY `code` (`code`),
  KEY `touid` (`touid`),
  KEY `dt` (`dt`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `credit_bank`
--

LOCK TABLES `credit_bank` WRITE;
/*!40000 ALTER TABLE `credit_bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_log`
--

DROP TABLE IF EXISTS `credit_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `credit_log` (
  `dt` datetime default NULL,
  `from_uid` int(11) NOT NULL default '0',
  `to_uid` int(11) NOT NULL default '0',
  `summa` double NOT NULL default '0',
  `opcode` varchar(40) NOT NULL default '',
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `_DT` (`dt`),
  KEY `__F` (`from_uid`),
  KEY `__T` (`to_uid`),
  KEY `__OP` (`opcode`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `credit_log`
--

LOCK TABLES `credit_log` WRITE;
/*!40000 ALTER TABLE `credit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credits_transactions`
--

DROP TABLE IF EXISTS `credits_transactions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `credits_transactions` (
  `id` int(20) unsigned NOT NULL auto_increment,
  `summa` double NOT NULL default '0',
  `from_user` int(20) unsigned NOT NULL default '0',
  `to_user` int(20) unsigned NOT NULL default '0',
  `to_nick` char(16) NOT NULL default '',
  `committed` char(1) NOT NULL default '0',
  `create_time` datetime default NULL,
  `commit_time` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `_fu` (`from_user`),
  KEY `_tu` (`to_user`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `credits_transactions`
--

LOCK TABLES `credits_transactions` WRITE;
/*!40000 ALTER TABLE `credits_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `credits_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters_in`
--

DROP TABLE IF EXISTS `filters_in`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `filters_in` (
  `folder_id` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `owner_uid` int(10) unsigned NOT NULL default '0',
  KEY `owner_uid` (`owner_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `filters_in`
--

LOCK TABLES `filters_in` WRITE;
/*!40000 ALTER TABLE `filters_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `filters_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters_out`
--

DROP TABLE IF EXISTS `filters_out`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `filters_out` (
  `folder_id` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `owner_uid` int(10) unsigned NOT NULL default '0',
  KEY `owner_uid` (`owner_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `filters_out`
--

LOCK TABLES `filters_out` WRITE;
/*!40000 ALTER TABLE `filters_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `filters_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_contents`
--

DROP TABLE IF EXISTS `folder_contents`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `folder_contents` (
  `folder_id` int(11) NOT NULL default '0',
  `message_id` int(11) NOT NULL default '0',
  KEY `_k1` (`folder_id`),
  KEY `_k12` (`message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `folder_contents`
--

LOCK TABLES `folder_contents` WRITE;
/*!40000 ALTER TABLE `folder_contents` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_messages`
--

DROP TABLE IF EXISTS `forum_messages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_messages` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `author` varchar(20) default NULL,
  `subj` text,
  `msg` text,
  `tid` int(20) unsigned NOT NULL default '0',
  `nid` int(20) unsigned NOT NULL default '0',
  `uid` int(20) unsigned NOT NULL default '0',
  `ip` varchar(20) default NULL,
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`),
  KEY `uidk` (`nid`),
  KEY `nidk` (`uid`),
  KEY `tidk` (`tid`),
  KEY `add_datek` (`add_date`)
) ENGINE=MyISAM AUTO_INCREMENT=41091 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_messages`
--

LOCK TABLES `forum_messages` WRITE;
/*!40000 ALTER TABLE `forum_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_themes`
--

DROP TABLE IF EXISTS `forum_themes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_themes` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `author` varchar(20) default NULL,
  `name` text,
  `nid` int(20) unsigned NOT NULL default '0',
  `uid` int(20) unsigned NOT NULL default '0',
  `ip` varchar(20) default NULL,
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `create_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `msgcnt` int(20) NOT NULL default '0',
  `last_by` varchar(17) NOT NULL default '',
  `last_by_id` int(20) unsigned default '0',
  PRIMARY KEY  (`ID`),
  KEY `uidk` (`nid`),
  KEY `nidk` (`uid`),
  KEY `add_datek` (`add_date`)
) ENGINE=MyISAM AUTO_INCREMENT=10928 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_themes`
--

LOCK TABLES `forum_themes` WRITE;
/*!40000 ALTER TABLE `forum_themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funnypics`
--

DROP TABLE IF EXISTS `funnypics`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `funnypics` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `name` text,
  `descr` text,
  `showed` int(11) NOT NULL default '0',
  `rating` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `funnypics`
--

LOCK TABLES `funnypics` WRITE;
/*!40000 ALTER TABLE `funnypics` DISABLE KEYS */;
/*!40000 ALTER TABLE `funnypics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grant_agrees`
--

DROP TABLE IF EXISTS `grant_agrees`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grant_agrees` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `gid` int(20) unsigned NOT NULL default '0',
  `uid` int(20) unsigned NOT NULL default '0',
  `yes` int(20) NOT NULL default '0',
  `no` int(20) NOT NULL default '0',
  `login` char(20) default NULL,
  PRIMARY KEY  (`ID`),
  KEY `gidk` (`gid`),
  KEY `uidk` (`uid`),
  KEY `yesk` (`yes`),
  KEY `nok` (`no`)
) ENGINE=MyISAM AUTO_INCREMENT=11793 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grant_agrees`
--

LOCK TABLES `grant_agrees` WRITE;
/*!40000 ALTER TABLE `grant_agrees` DISABLE KEYS */;
/*!40000 ALTER TABLE `grant_agrees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grant_messages`
--

DROP TABLE IF EXISTS `grant_messages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grant_messages` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `gid` int(20) unsigned NOT NULL default '0',
  `from_nick` text,
  `ip` varchar(20) default NULL,
  `msg` text,
  `add_date` datetime default NULL,
  `show_nick` char(1) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `gidk` (`gid`)
) ENGINE=MyISAM AUTO_INCREMENT=9071 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grant_messages`
--

LOCK TABLES `grant_messages` WRITE;
/*!40000 ALTER TABLE `grant_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `grant_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grant_readden`
--

DROP TABLE IF EXISTS `grant_readden`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grant_readden` (
  `readden` char(1) NOT NULL default '',
  `uid` int(20) unsigned NOT NULL default '0',
  `gid` int(20) unsigned NOT NULL default '0',
  KEY `uid_key` (`uid`),
  KEY `gid_key` (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grant_readden`
--

LOCK TABLES `grant_readden` WRITE;
/*!40000 ALTER TABLE `grant_readden` DISABLE KEYS */;
/*!40000 ALTER TABLE `grant_readden` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grant_vote`
--

DROP TABLE IF EXISTS `grant_vote`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grant_vote` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `nick` char(20) default NULL,
  `llevel` int(10) default NULL,
  `nlevel` int(10) default NULL,
  `uid` int(20) NOT NULL default '0',
  `add_date` datetime default NULL,
  `add_by` int(20) default NULL,
  `status` char(1) default NULL,
  PRIMARY KEY  (`ID`),
  KEY `uidk` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1068 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grant_vote`
--

LOCK TABLES `grant_vote` WRITE;
/*!40000 ALTER TABLE `grant_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `grant_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hints`
--

DROP TABLE IF EXISTS `hints`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hints` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `txt` text NOT NULL,
  `lang` char(3) NOT NULL default '',
  `uid` int(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `lang_key` (`lang`),
  KEY `uid_key` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hints`
--

LOCK TABLES `hints` WRITE;
/*!40000 ALTER TABLE `hints` DISABLE KEYS */;
/*!40000 ALTER TABLE `hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `histories`
--

DROP TABLE IF EXISTS `histories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `histories` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `txt` text,
  `rating` int(11) NOT NULL default '0',
  `add_date` datetime default NULL,
  `add_by` text,
  `chk` int(1) NOT NULL default '0',
  `ip` text,
  PRIMARY KEY  (`ID`),
  KEY `chk_k` (`chk`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `histories`
--

LOCK TABLES `histories` WRITE;
/*!40000 ALTER TABLE `histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ignores`
--

DROP TABLE IF EXISTS `ignores`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ignores` (
  `uid` int(10) unsigned NOT NULL default '0',
  `cuid` int(10) unsigned NOT NULL default '0',
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ignores`
--

LOCK TABLES `ignores` WRITE;
/*!40000 ALTER TABLE `ignores` DISABLE KEYS */;
/*!40000 ALTER TABLE `ignores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `news` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `uid` int(20) unsigned NOT NULL default '0',
  `add_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `lang` text,
  `txt` text,
  `add_nid` int(20) unsigned default '0',
  `add_by` text NOT NULL,
  PRIMARY KEY  (`ID`),
  KEY `uid_key` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nicks`
--

DROP TABLE IF EXISTS `nicks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `nicks` (
  `ID` int(10) unsigned NOT NULL default '0',
  `Login` varchar(18) NOT NULL default '0',
  `Nick` varchar(17) NOT NULL default '',
  `str_nick` varchar(17) NOT NULL default '',
  `Banned` int(2) default NULL,
  `uid` int(10) NOT NULL default '0',
  `bby` int(10) NOT NULL default '0',
  `ready_to_sale` char(1) NOT NULL default '0',
  `cost` double NOT NULL default '0',
  KEY `ID` (`ID`),
  KEY `_nick` (`Nick`),
  KEY `uidk` (`uid`),
  KEY `logink` (`Login`),
  KEY `bby_key` (`bby`),
  KEY `uppernick_key` (`str_nick`),
  KEY `banned_key` (`Banned`),
  KEY `ready_to_sale` (`ready_to_sale`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `nicks`
--

LOCK TABLES `nicks` WRITE;
/*!40000 ALTER TABLE `nicks` DISABLE KEYS */;
/*!40000 ALTER TABLE `nicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_folders`
--

DROP TABLE IF EXISTS `note_folders`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `note_folders` (
  `id` int(10) unsigned NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `name` blob,
  KEY `_uid` (`uid`),
  KEY `_id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `note_folders`
--

LOCK TABLES `note_folders` WRITE;
/*!40000 ALTER TABLE `note_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_texts`
--

DROP TABLE IF EXISTS `note_texts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `note_texts` (
  `message_id` int(11) NOT NULL default '0',
  `body` blob,
  `owner_uid` int(10) unsigned NOT NULL default '0',
  KEY `_kM1` (`message_id`),
  KEY `__owner_uid` (`owner_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `note_texts`
--

LOCK TABLES `note_texts` WRITE;
/*!40000 ALTER TABLE `note_texts` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `notes` (
  `id` int(10) unsigned NOT NULL default '0',
  `from_nick_id` int(11) NOT NULL default '0',
  `to_nick_id` int(11) NOT NULL default '0',
  `from_uid` int(11) NOT NULL default '0',
  `to_uid` int(11) NOT NULL default '0',
  `from_nick` varchar(100) NOT NULL default '',
  `to_nick` varchar(100) NOT NULL default '',
  `refcount` int(11) NOT NULL default '0',
  `subject` blob,
  `send_date` datetime default NULL,
  `status` char(1) NOT NULL default '0',
  `unread` char(1) NOT NULL default '1',
  `content_length` int(11) NOT NULL default '0',
  `has_attachment` char(1) NOT NULL default '0',
  `attachment_filename` text,
  `attachment_content_length` int(11) NOT NULL default '0',
  `important` char(1) NOT NULL default '0',
  `system` char(1) NOT NULL default '0',
  `owner_folder` int(10) unsigned NOT NULL default '0',
  `owner_uid` int(10) unsigned NOT NULL default '0',
  `notify_read` int(10) unsigned NOT NULL default '0',
  KEY `owner_folder` (`owner_folder`),
  KEY `owner_uid` (`owner_uid`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_filters`
--

DROP TABLE IF EXISTS `notes_filters`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `notes_filters` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `uid` int(20) unsigned NOT NULL default '0',
  `fid` int(20) unsigned NOT NULL default '0',
  `to_folder` int(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `uid_key` (`uid`),
  KEY `fid_key` (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=113893 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `notes_filters`
--

LOCK TABLES `notes_filters` WRITE;
/*!40000 ALTER TABLE `notes_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_folders`
--

DROP TABLE IF EXISTS `notes_folders`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `notes_folders` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `uid` int(20) unsigned NOT NULL default '0',
  `name` char(30) NOT NULL default '',
  `show_new` char(1) NOT NULL default '1',
  `cant_remove` char(1) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `cid_key` (`uid`),
  KEY `show_new_key` (`show_new`)
) ENGINE=MyISAM AUTO_INCREMENT=228860 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `notes_folders`
--

LOCK TABLES `notes_folders` WRITE;
/*!40000 ALTER TABLE `notes_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `photos` (
  `ID` int(10) unsigned NOT NULL default '0',
  `filename` text,
  `orig_filename` text,
  `descr` text,
  `sx` int(20) default NULL,
  `sy` int(20) default NULL,
  `uid` int(20) unsigned NOT NULL default '0',
  `size` int(10) NOT NULL default '0',
  `ext` text NOT NULL,
  `rating` blob NOT NULL,
  `rating_result` int(11) NOT NULL default '0',
  KEY `ID` (`ID`),
  KEY `uidi` (`uid`),
  KEY `rating_result` (`rating_result`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pincodes`
--

DROP TABLE IF EXISTS `pincodes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pincodes` (
  `v1` int(11) NOT NULL default '0',
  `v2` int(11) NOT NULL default '0',
  `v3` int(11) NOT NULL default '0',
  `full_v` varchar(14) NOT NULL default '0',
  `summa` int(11) NOT NULL default '0',
  `sent_to_provider` char(1) default '0',
  `accepted` char(1) default '0',
  `date_accepted` datetime NOT NULL default '2000-01-01 00:00:00',
  `date_created` datetime NOT NULL default '2000-01-01 00:00:00',
  `accepted_by_uid` int(11) NOT NULL default '0',
  `sms` text,
  `sent_to` varchar(100) NOT NULL default '',
  UNIQUE KEY `full_v` (`full_v`),
  KEY `_accepted` (`accepted`),
  KEY `_summa` (`summa`),
  KEY `_sent_to_provider` (`sent_to_provider`),
  KEY `_v1` (`v1`),
  KEY `_v2` (`v2`),
  KEY `_v3` (`v3`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pincodes`
--

LOCK TABLES `pincodes` WRITE;
/*!40000 ALTER TABLE `pincodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pincodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `topics` (
  `channel` int(11) NOT NULL default '-1',
  `topic` blob,
  `current_price` double NOT NULL default '0',
  `orig_price` double NOT NULL default '0',
  `owner` int(11) NOT NULL default '0',
  `last_recalc` datetime default '1970-01-01 00:00:00',
  `disabled` char(1) NOT NULL default '0',
  `set_time` datetime NOT NULL default '0000-00-00 00:00:00',
  KEY `__C` (`channel`),
  KEY `__LC` (`last_recalc`),
  KEY `__D` (`disabled`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_credits`
--

DROP TABLE IF EXISTS `user_credits`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_credits` (
  `refid` int(10) unsigned NOT NULL default '0',
  `summa` double NOT NULL default '0',
  `last_access` datetime default '0000-00-00 00:00:00',
  KEY `_refid` (`refid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_credits`
--

LOCK TABLES `user_credits` WRITE;
/*!40000 ALTER TABLE `user_credits` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profiles`
--

DROP TABLE IF EXISTS `user_profiles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_profiles` (
  `refid` int(20) unsigned NOT NULL default '0',
  `icq` text,
  `city` text,
  `info` text,
  `homepage` text,
  `tel` text,
  `b_day` varchar(10) NOT NULL default '',
  `b_mon` int(3) NOT NULL default '0',
  `b_year` varchar(4) NOT NULL default '1980',
  `fname` text,
  `lname` text,
  `email` text,
  `reg_date` datetime default NULL,
  `level` int(10) unsigned NOT NULL default '100',
  `login` varchar(18) NOT NULL default '',
  `pass` text,
  `vote_balls` int(10) default NULL,
  `db_privileges` int(10) NOT NULL default '0',
  `upperlogin` varchar(20) NOT NULL default '',
  `gender` char(1) NOT NULL default '0',
  `has_clan` char(1) NOT NULL default '0',
  PRIMARY KEY  (`refid`),
  KEY `_login` (`login`),
  KEY `_vb` (`vote_balls`),
  KEY `_rd` (`reg_date`),
  KEY `_dp` (`db_privileges`),
  KEY `lv` (`level`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_profiles`
--

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sets`
--

DROP TABLE IF EXISTS `user_sets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_sets` (
  `refid` int(20) unsigned NOT NULL default '0',
  `lpp` int(3) NOT NULL default '0',
  `show_nicks` char(1) NOT NULL default '1',
  `show_level` char(1) NOT NULL default '1',
  `neye` int(3) NOT NULL default '0',
  `n_color_pack` int(4) NOT NULL default '0',
  `bought_quota` int(10) NOT NULL default '0',
  `bought_max_nick_count` int(10) NOT NULL default '0',
  `contact_mode` char(1) NOT NULL default '0',
  `contact_options` int(10) unsigned NOT NULL default '0',
  `bought_invisibility` double NOT NULL default '0',
  `notes_msg_per_page` int(11) NOT NULL default '20',
  `notes_save_copy` char(1) NOT NULL default '0',
  `notes_sort` char(1) NOT NULL default '1',
  `notes_sort_desc` char(1) NOT NULL default '1',
  `poweshen` int(11) NOT NULL default '0',
  `binv_last_recalc` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_nick_id` int(11) NOT NULL default '0',
  `last_nick` text NOT NULL,
  `last_channel` int(11) NOT NULL default '0',
  `last_status_id` int(11) NOT NULL default '0',
  `setting_autologin` char(1) NOT NULL default '0',
  `setting_autochange` char(1) NOT NULL default '0',
  `setting_show_eye` char(1) NOT NULL default '0',
  `setting_show_hints` char(1) NOT NULL default '0',
  `setting_show_stat` char(1) NOT NULL default '0',
  `setting_invite_sound` char(1) NOT NULL default '0',
  `setting_full_buttons` char(1) NOT NULL default '0',
  `hide_fname` char(1) NOT NULL default '0',
  `hide_lname` char(1) NOT NULL default '0',
  `hide_bdate` char(1) NOT NULL default '0',
  `hide_tel` char(1) NOT NULL default '0',
  `hide_icq` char(1) NOT NULL default '0',
  `hide_email` char(1) NOT NULL default '0',
  `ul_mode_hide_female` char(1) NOT NULL default '0',
  `ul_mode_hide_male` char(1) NOT NULL default '0',
  `ul_mode_contacts_only` char(1) NOT NULL default '0',
  `show_credits` char(1) NOT NULL default '0',
  PRIMARY KEY  (`refid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_sets`
--

LOCK TABLES `user_sets` WRITE;
/*!40000 ALTER TABLE `user_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_settings` (
  `ID` int(20) unsigned NOT NULL auto_increment,
  `uid` int(20) unsigned NOT NULL default '0',
  `greeting` int(20) default NULL,
  `bye` int(20) default NULL,
  `anick` int(10) NOT NULL default '0',
  `cstatus` int(20) default NULL,
  `channel` int(20) default NULL,
  `show_nicks` char(1) NOT NULL default '0',
  `show_level` char(1) NOT NULL default '1',
  `notes_sent_folder` int(20) unsigned NOT NULL default '0',
  `notes_msg_per_page` int(20) unsigned NOT NULL default '20',
  `notes_sort_by` char(25) NOT NULL default 'sent_date desc',
  `notes_save_copy` char(1) NOT NULL default '1',
  `n_color_pack` int(20) default '0',
  `settings` int(20) unsigned default '0',
  PRIMARY KEY  (`ID`),
  KEY `uidi` (`uid`),
  KEY `anick_key` (`anick`)
) ENGINE=MyISAM AUTO_INCREMENT=113726 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_stats`
--

DROP TABLE IF EXISTS `user_stats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_stats` (
  `refid` int(20) unsigned NOT NULL auto_increment,
  `last_date` datetime NOT NULL default '2006-01-01 00:00:00',
  `last_ip` text NOT NULL,
  `v_count` int(11) NOT NULL default '0',
  `m_count` int(10) NOT NULL default '0',
  `t_count` int(10) NOT NULL default '0',
  `kick_count` int(10) unsigned NOT NULL default '0',
  `kicked_count` int(10) unsigned NOT NULL default '0',
  `last_pip` text NOT NULL,
  PRIMARY KEY  (`refid`)
) ENGINE=MyISAM AUTO_INCREMENT=113894 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_stats`
--

LOCK TABLES `user_stats` WRITE;
/*!40000 ALTER TABLE `user_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_status`
--

DROP TABLE IF EXISTS `user_status`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_status` (
  `ID` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `name` text,
  `pic` int(11) default NULL,
  `disable_invite` char(1) NOT NULL default '0',
  `uniq` char(1) NOT NULL default '0',
  KEY `ID` (`ID`),
  KEY `uidi` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_status`
--

LOCK TABLES `user_status` WRITE;
/*!40000 ALTER TABLE `user_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=113894 DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_count`
--

DROP TABLE IF EXISTS `users_count`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users_count` (
  `dt` datetime NOT NULL default '0000-00-00 00:00:00',
  `cnt` int(10) NOT NULL default '0',
  PRIMARY KEY  (`dt`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users_count`
--

LOCK TABLES `users_count` WRITE;
/*!40000 ALTER TABLE `users_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_count` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-04-08 18:16:46
